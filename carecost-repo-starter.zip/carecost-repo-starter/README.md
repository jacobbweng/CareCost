# CareCost

**Making healthcare financially and physically accessible.**

CareCost is an AI-powered, disability-aware healthcare navigation concept designed to help people with disabilities find providers that accommodate their needs while understanding and comparing the total estimated cost of receiving care.

> **Hackathon theme:** Accessibility tools for navigating the medical care system for disabled users.

## The problem

Finding a healthcare provider is about more than finding the lowest listed price or the closest location. A provider may be affordable but lack an accommodation a patient needs. Another provider may have a higher medical price but be easier and less expensive to access overall. Insurance rules, transportation, and other expenses can make comparisons even harder.

## Our approach

CareCost brings accessibility information and healthcare cost estimates into one navigation experience. It is intended to help users:

- Describe essential accessibility requirements and preferred accommodations.
- Discover and compare healthcare providers using accessibility, insurance, location, and cost information.
- Estimate the broader cost of accessing care, not just the medical bill.
- Understand insurance terminology and identify questions to ask their insurer.
- Prepare a personalized checklist for contacting and visiting a provider.

## Core features planned

1. **Accessibility-aware provider matching** — prioritize essential accommodations and clearly distinguish confirmed, unavailable, and unverified information.
2. **True Cost Calculator** — estimate medical responsibility and user-entered transportation, assistance, parking, and other expenses.
3. **Insurance Navigator** — explain policy language and estimate potential patient costs using transparent assumptions.
4. **Provider comparison and accessibility map** — compare options and explore geographic availability, with an accessible list alternative.
5. **Personalized care navigation** — generate practical preparation steps based on the user's selected requirements.

## Important data and safety notes

The hackathon prototype may use fictional demonstration providers and synthetic prices. Synthetic data must be clearly labeled and must never be presented as verified information about a real provider or insurer. Accessibility details should be labeled as verified, self-reported, unknown, or sample data, with dates where available.

Cost and insurance outputs are estimates, not guarantees of coverage, claims decisions, or final bills. CareCost is a navigation and information tool, not a medical provider, insurer, or source of medical diagnosis or treatment advice.

The product should not require users to disclose a diagnosis. Users should be able to specify the accommodations they need directly.

## Development status

**Status:** Hackathon prototype in development.

The initial implementation should prioritize a working end-to-end demonstration: user accessibility profile → provider matching → transparent cost comparison → personalized next-step checklist.

## Getting started

The application setup instructions will be added once the framework and project structure are established. See [`CLAUDE.md`](./CLAUDE.md) and [`PROJECT_CONTEXT.md`](./PROJECT_CONTEXT.md) for development guidance and product requirements.

## Accessibility principles

CareCost itself should be accessible. Development should follow WCAG 2.2 AA practices where practical, including semantic HTML, keyboard navigation, visible focus states, readable contrast, accessible form labels and errors, reduced-motion support, and a non-map alternative for provider discovery.

## Contributors

Built for a student hackathon. Add contributor names and acknowledgements here as appropriate.
